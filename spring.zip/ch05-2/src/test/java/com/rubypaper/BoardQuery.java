package com.rubypaper;

import java.util.Arrays;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.rubypaper.domain.Board;
import com.rubypaper.persistancer.BoardRepositoryQuery;

@SpringBootTest
public class BoardQuery {
	@Autowired
	private	BoardRepositoryQuery boardRepoQuery;
	
//	@Test
	public void test1() {
		List<Board> boardList = boardRepoQuery.getBoardList1("10");
		for(Board board:boardList)
			System.out.println("--->" + board.toString());
	}
	
//	@Test
	public void test2() {
		List<Board> boardList = boardRepoQuery.getBoardList2("20");
		for(Board board:boardList)
			System.out.println("--->" + board.toString());
	}
	
//	@Test
	public void test3() {
		List<Object[]> boardList = boardRepoQuery.getBoardList3("30");
		System.out.println("이름기반 object");
		for(Object[] board:boardList)
			System.out.println("--->" + Arrays.toString(board));
	}
	
//	@Test
	public void test4() {
		List<Object[]> boardList = boardRepoQuery.getBoardList3("40");
		System.out.println("이름기반 native query");
		for(Object[] board:boardList)
			System.out.println("--->" + Arrays.toString(board));
	}
	
	@Test
	public void testpaging() {
		Pageable paging = PageRequest.of(0, 5);
		List<Object[]> boardList = boardRepoQuery.getBoardList5(paging);
		System.out.println("page");
		for(Object[] board:boardList)
			System.out.println("--->" + Arrays.toString(board));
	}
}

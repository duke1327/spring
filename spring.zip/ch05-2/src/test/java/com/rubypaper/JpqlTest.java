package com.rubypaper;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;

import com.rubypaper.domain.Board;
import com.rubypaper.persistancer.BoardRepository;

@SpringBootTest
public class JpqlTest {
	@Autowired
	private BoardRepository boardRepo;
//	@Test
//	@BeforeEach
//	@AfterEach
	public void testInsert() {
		for(int i=1;i<=100;i++) {
			Board board = new Board();
			board.setTitle("title1"+i);
			board.setWriter(i+"Leesuman");
			board.setContent("hello1"+i);
			board.setCreateDate(new Date());
			board.setCnt(i);
			boardRepo.save(board);
		}
	}
	
//	@Test
	public void test1() {
		List<Board> boardList = boardRepo.findBoardByTitle("title17");
		System.out.println("--->findBoardByTitle()");
		for(Board b:boardList)
			System.out.println("->"+b.toString());
	}
	
//	@Test
	public void test2() {
		List<Board> boardList = boardRepo.findBoardByTitleContaining("7");
		System.out.println("--->findBoardByTitle()");
		for(Board b:boardList)
			System.out.println("->"+b.toString());
	}
	
//	@Test
	public void test3() {
		List<Board> boardList = boardRepo.findBoardByTitleContainingOrContentContaining("8", "7");
		System.out.println("--->findBoardByTitle()");
		for(Board b:boardList)
			System.out.println("->"+b.toString());
	}
	
//	@Test
	public void test4() {
		List<Board> boardList = boardRepo.findByTitleContainingOrderBySeqDesc("7");
		System.out.println("--->findBoardByTitle()");
		for(Board b:boardList)
			System.out.println("->"+b.toString());
	}
	
//	@Test
	public void test5() {
//		Pageable paging = PageRequest.of(1, 3);
		Pageable paging = PageRequest.of(0, 5, Sort.Direction.DESC, "seq");
		List<Board> boardList = boardRepo.findByWriterContaining("4", paging);
		System.out.println("--->findBoardByTitle()");
		for(Board b:boardList)
			System.out.println("->"+b.toString());
	}
	
//	@Test
	public void test6() {
		Pageable paging = PageRequest.of(0, 5, Sort.Direction.DESC, "seq");
		Page<Board> boardList = boardRepo.findByContentContaining("9", paging);
		System.out.println("--->findBoardByTitle()");
		for(Board b:boardList.getContent())
			System.out.println("->"+b.toString());
		// 정보확인
		System.out.println("전체 데이터 수 " + boardList.getTotalElements());
		System.out.println("전체 페이지 수 " + boardList.getTotalPages());
		System.out.println("페이지 당 튜플 수 " + boardList.getSize());
	}
	
	@Test
	public void test7() {
		List<Board> boardList = boardRepo.findByWriterStartingWith("4");
		System.out.println("--->findByWriterLike()");
		for(Board b:boardList)
			System.out.println("->"+b.toString());
	}
}

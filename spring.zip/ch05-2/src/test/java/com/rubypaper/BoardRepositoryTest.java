package com.rubypaper;

import java.util.Date;
import java.util.Optional;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.rubypaper.domain.Board;
import com.rubypaper.persistancer.BoardRepository;

@SpringBootTest
public class BoardRepositoryTest {
	@Autowired
	BoardRepository boardRepo;
	
//	@Test
	public void testInsertBoard() {
		Board board = new Board();
		board.setTitle("title1");
		board.setWriter("Leesuman");
		board.setContent("hello1");
		board.setCreateDate(new Date());
		board.setCnt(0);
		boardRepo.save(board);
	}
	
	@Test
	public void testUpdateBoard() {
		Board board = new Board();
		board.setSeq(1);
		board.setTitle("수정1");
		board.setWriter("수정");
		board.setContent("hello11");
		board.setCreateDate(new Date());
		board.setCnt(0);
		boardRepo.save(board);
	}
	
//	@Test
	public void testFind() {
		Optional<Board> findBoard = boardRepo.findById(1);
		Board board = findBoard.get();
		System.out.println("--->" + board.toString());
	}
	
//	@Test
	public void testUpdate() {
		Board board = new Board();
		board.setWriter("김지민");
		boardRepo.save(board);
	}
	
//	@Test
	public void testDelete() {
		boardRepo.deleteById(1);
	}
}

package com.rubypaper;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import com.querydsl.core.BooleanBuilder;
import com.rubypaper.domain.Board;
import com.rubypaper.domain.QBoard;
import com.rubypaper.persistancer.BoardRepository;
import com.rubypaper.persistancer.BoardRepositoryDsl;

@SpringBootTest
public class BoardRepoDslTest {
	@Autowired
	private BoardRepository boardRepo;
	@Autowired
	private BoardRepositoryDsl boardRepoDsl;
	
//	@Test
	public void queryDsl1() {
		Iterable<Board> boardList = boardRepoDsl.findAll();
		System.out.println("---boardRepoDsl---");
		for(Board board:boardList)
			System.out.println(board.toString());
	}
	
//	@Test
	public void queryDsl2() {
		Iterable<Board> boardList = boardRepo.findAll();
		System.out.println("---boardRepo---");
		for(Board board:boardList)
			System.out.println(board.toString());
	}
	
//	@Test
	public void queryDsl3() {
		BooleanBuilder builder = new BooleanBuilder();
		String con1 = "title";
		String key = "88";
		QBoard qboard = QBoard.board;
		if(con1.equals("title")) {
			builder.and(qboard.title.like("%"+key+"%"));
		} else if(con1.equals("content")) {
			builder.and(qboard.content.like("%"+key+"%"));
		}
		Iterable<Board> boardList = boardRepoDsl.findAll(builder);
		System.out.println("---qboard---");
		for(Board board:boardList)
			System.out.println(board.toString());
	}
	
	@Test
	public void queryDsl4() {
		BooleanBuilder builder = new BooleanBuilder();
		String con1 = "title";
		String key = "17";
		QBoard qboard = QBoard.board;
		if(con1.equals("title")) {
			builder.and(qboard.title.like("%"+key+"%"));
		} else if(con1.equals("content")) {
			builder.and(qboard.content.like("%"+key+"%"));
		}
		
		Pageable paging = PageRequest.of(0, 3);
		
		Page<Board> boardList = boardRepoDsl.findAll(builder, paging);
		System.out.println("---qboard---");
		for(Board board:boardList.getContent())
			System.out.println(board.toString());
	}
}

package com.rubypaper.persistancer;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

import com.rubypaper.domain.Board;

public interface BoardRepository extends JpaRepository<Board, Integer>{
//	1. BoardRepositoryTest.java JpaRepository interface 있는 메소드 이
//	   시험문제는 save() findById() deleteById()
//	2. JPQL의 메소드 만드는 방식 이용 자동 h2 기반의 쿼리문 생성
	List<Board> findBoardByTitle(String key);
	List<Board> findBoardByTitleContaining(String key);
	List<Board> findBoardByTitleContainingOrContentContaining(String title, String content);
	List<Board> findByTitleContainingOrderBySeqDesc(String key);
	List<Board> findByWriterContaining(String key, Pageable paging);
	Page<Board> findByContentContaining(String key, Pageable paging);
	List<Board> findByWriterStartingWith(String key);
}
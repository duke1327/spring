package com.rubypaper.persistancer;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.rubypaper.domain.Board;

public interface BoardRepositoryQuery extends JpaRepository<Board, Integer> {
	@Query("select b from Board b where b.title like %?1% order by b.seq desc")
	List<Board> getBoardList1(String key);
	
	@Query("select b from Board b where b.title like %:keyword% order by b.seq desc")
	List<Board> getBoardList2(@Param("keyword") String key);
	
	@Query("select b.seq, b.title, b.writer from Board b where b.title like %:keyword% order by b.seq desc")
	List<Object[]> getBoardList3(@Param("keyword") String key);
	
	@Query(value = "select seq, title from Board where title like %:keyword%", nativeQuery=true)
	List<Object[]> getBoardList4(@Param("keyword") String key);
	
	@Query(value = "select seq, title from Board")
	List<Object[]> getBoardList5(Pageable paging);
}

package com.rubypaper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ch052Application {

	public static void main(String[] args) {
		SpringApplication.run(Ch052Application.class, args);
	}

}
